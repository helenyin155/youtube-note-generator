package com.aminoacids.youtubenotes.exceptions;

public class UserException {
}
