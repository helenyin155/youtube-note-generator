package com.aminoacids.youtubenotes.mapping;

public class FileMapping {
}
