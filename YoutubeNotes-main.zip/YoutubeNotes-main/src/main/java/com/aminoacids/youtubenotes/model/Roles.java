package com.aminoacids.youtubenotes.model;

public enum Roles {
    USER,
    ADMIN
}
